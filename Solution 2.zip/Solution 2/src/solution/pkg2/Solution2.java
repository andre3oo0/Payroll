package solution.pkg2;

import java.util.Scanner;

public class Solution2 {

    public class Andrew_Payroll {

        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            Scanner cs = new Scanner(System.in);

            System.out.println("Please enter how many hours you worked");
            int hoursworked = sc.nextInt();

            System.out.println("Please enter your shift number: ");
            int shiftnum = sc.nextInt();

            if (shiftnum == 1) {

                double hourlypayrate = 50;
                double regularpay = hoursworked * hourlypayrate;
                if (hoursworked > 40) {
                    regularpay = 40 * hourlypayrate;
                }
                int overtime = hoursworked - 40;
                double overtimepay = overtime * 75;
                double reovt = regularpay + overtimepay;

                System.out.println("Hours worked: " + hoursworked);
                System.out.println("Shift number: " + shiftnum);
                System.out.println("Hourly pay rate: " + "R" + hourlypayrate + " per hour");
                System.out.println("Regular pay: " + "R" + regularpay);
                System.out.println("Overtime pay: " + "R" + overtimepay);
                System.out.println("Total of regular and overtime pay: " + "R" + reovt);
                System.out.println("Net pay: " + "R" + reovt);

            }

            if (shiftnum == 2) {

                double hourlypayrate = 70;
                double regularpay = hoursworked * hourlypayrate;

                if (hoursworked > 40) {
                    regularpay = 40 * hourlypayrate;
                }

                int overtime = hoursworked - 40;
                double overtimepay = overtime * 105;
                double reovt = regularpay + overtimepay;
                double redeuct = 0.05 * reovt;
                double netpay = reovt - redeuct;

                System.out.println("Hours worked: " + hoursworked);
                System.out.println("Shift number: " + shiftnum);
                System.out.println("Hourly pay rate: " + "R" + hourlypayrate + " per hour");
                System.out.println("Regular pay: " + "R" + regularpay);
                System.out.println("Overtime pay: " + "R" + overtimepay);

                System.out.println("Do you wish to participate in the retirement plan? (yes/no)");
                String choice = cs.nextLine();

                if ("yes".equals(choice)) {

                    System.out.println("Retirement deduction: " + "R" + redeuct);

                }

                System.out.println("Total of regular and overtime pay: " + "R" + reovt);
                System.out.println("Net pay: " + "R" + netpay);

            }

            if (shiftnum == 3) {

                double hourlypayrate = 90;
                double regularpay = hoursworked * hourlypayrate;
                if (hoursworked > 40) {
                    regularpay = 40 * hourlypayrate;
                }
                int overtime = hoursworked - 40;
                double overtimepay = overtime * 135;
                double reovt = regularpay + overtimepay;
                double redeuct = 0.05 * reovt;
                double netpay = reovt - redeuct;

                System.out.println("Hours worked: " + hoursworked);
                System.out.println("Shift number: " + shiftnum);
                System.out.println("Hourly pay rate: " + "R" + hourlypayrate + " per hour");
                System.out.println("Regular pay: " + "R" + regularpay);
                System.out.println("Overtime pay: " + "R" + overtimepay);

                System.out.println("Do you wish to participate in the retirement plan? (yes/no)");
                String choice = cs.nextLine();

                if ("yes".equals(choice)) {

                    System.out.println("Retirement deduction: " + "R" + redeuct);

                }
                System.out.println("Total of regular and overtime pay: " + "R" + reovt);
                System.out.println("Net pay: " + "R" + netpay);

            }
        }
    }
}
