package andrew_payroll;

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.*;

public class Andrew_PayrollTest {

    private static final double DELTA = 1e-2;

    private void clearFile(String filename) throws IOException {
        FileWriter fw = new FileWriter(filename);
        fw.write("");
        fw.close();
    }

    @Test
    public void testValidNewDataInput() {
        System.out.println("testValidNewDataInput");
        Employee employee = new Employee(40, 1, false);
        employee.calculatePay();

        double expRegularPay = 40 * 50;
        double expOvertimePay = 0;
        double expTotalPay = expRegularPay + expOvertimePay;
        double expNetPay = expTotalPay;

        assertTrue(employee.isValidShift());
        assertEquals(expRegularPay, employee.getRegularPay(), DELTA);
        assertEquals(expOvertimePay, employee.getOvertimePay(), DELTA);
        assertEquals(expTotalPay, employee.getTotalPay(), DELTA);
        assertEquals(expNetPay, employee.getNetPay(), DELTA);
    }

    @Test
    public void testInvalidHoursWorkedInput() {
        System.out.println("testInvalidHoursWorkedInput");
        try {
            Employee employee = new Employee(-5, 1, false);
            employee.calculatePay();
            fail("Expected IllegalArgumentException not thrown");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Hours worked cannot be negative"));
        }
    }

    @Test
    public void testInvalidShiftNumberInput() {
        System.out.println("testInvalidShiftNumberInput");
        Employee employee = new Employee(40, 4, false);
        employee.calculatePay();

        assertFalse(employee.isValidShift());
        assertEquals(0, employee.getRegularPay(), DELTA);
        assertEquals(0, employee.getOvertimePay(), DELTA);
        assertEquals(0, employee.getTotalPay(), DELTA);
        assertEquals(0, employee.getRetirementDeduction(), DELTA);
        assertEquals(0, employee.getNetPay(), DELTA);
    }

    @Test
    public void testProcessExistingValidData() throws IOException {
        System.out.println("testProcessExistingValidData");
        clearFile("hours_worked.txt");
        FileWriter fw = new FileWriter("hours_worked.txt", true);
        fw.write("40\n");
        fw.close();

        try {

        } catch (Exception e) {
            fail("Processing existing data failed: " + e.getMessage());
        }
    }

    @Test
    public void testProcessExistingCorruptedData() throws IOException {
        System.out.println("testProcessExistingCorruptedData");
        clearFile("hours_worked.txt");
        FileWriter fw = new FileWriter("hours_worked.txt", true);
        fw.write("invalid data\n");
        fw.close();

        try {
        } catch (Exception e) {
            assertTrue(e instanceof IOException);
        }
    }

    @Test
    public void testReadFromExistingFile() throws IOException {
        System.out.println("testReadFromExistingFile");
        clearFile("hours_worked.txt");
        FileWriter fw = new FileWriter("hours_worked.txt", true);
        fw.write("30\n");
        fw.close();

        try {

        } catch (Exception e) {
            fail("Reading from existing file failed: " + e.getMessage());
        }
    }

    @Test
    public void testWriteToFile() throws IOException {
        System.out.println("testWriteToFile");
        clearFile("hours_worked.txt");

        Employee employee = new Employee(30, 1, false);
        employee.calculatePay();

        FileWriter fw = new FileWriter("hours_worked.txt", true);
        fw.write("30\n");
        fw.close();

        BufferedReader br = new BufferedReader(new FileReader("hours_worked.txt"));
        String line = br.readLine();
        assertEquals("30", line);
        br.close();
    }

    @Test
    public void testValidatePayCalculationWithOvertime() {
        System.out.println("testValidatePayCalculationWithOvertime");
        Employee employee = new Employee(45, 3, false);
        employee.calculatePay();

        double expRegularPay = 40 * 90;
        double expOvertimePay = 5 * 135;
        double expTotalPay = expRegularPay + expOvertimePay;
        double expRetirementDeduction = 0;
        double expNetPay = expTotalPay;

        assertTrue(employee.isValidShift());
        assertEquals(expRegularPay, employee.getRegularPay(), DELTA);
        assertEquals(expOvertimePay, employee.getOvertimePay(), DELTA);
        assertEquals(expTotalPay, employee.getTotalPay(), DELTA);
        assertEquals(expRetirementDeduction, employee.getRetirementDeduction(), DELTA);
        assertEquals(expNetPay, employee.getNetPay(), DELTA);
    }

    @Test
    public void testValidatePayCalculationWithoutOvertime() {
        System.out.println("testValidatePayCalculationWithoutOvertime");
        Employee employee = new Employee(40, 2, false);
        employee.calculatePay();

        double expRegularPay = 40 * 70;
        double expOvertimePay = 0;
        double expTotalPay = expRegularPay + expOvertimePay;
        double expRetirementDeduction = 0;
        double expNetPay = expTotalPay;

        assertTrue(employee.isValidShift());
        assertEquals(expRegularPay, employee.getRegularPay(), DELTA);
        assertEquals(expOvertimePay, employee.getOvertimePay(), DELTA);
        assertEquals(expTotalPay, employee.getTotalPay(), DELTA);
        assertEquals(expRetirementDeduction, employee.getRetirementDeduction(), DELTA);
        assertEquals(expNetPay, employee.getNetPay(), DELTA);
    }

    @Test
    public void testWithRetirementPlanShift3() {
        System.out.println("testWithRetirementPlanShift3");
        Employee employee = new Employee(50, 3, true);
        employee.calculatePay();

        double hourlyPayRate = 90;
        double expRegularPay = 40 * hourlyPayRate;
        double expOvertimePay = (50 - 40) * hourlyPayRate * 1.5;
        double expTotalPay = expRegularPay + expOvertimePay;
        double expRetirementDeduction = 0.05 * expTotalPay;
        double expNetPay = expTotalPay - expRetirementDeduction;

        assertTrue(employee.isValidShift());
        assertEquals(expRegularPay, employee.getRegularPay(), DELTA);
        assertEquals(expOvertimePay, employee.getOvertimePay(), DELTA);
        assertEquals(expTotalPay, employee.getTotalPay(), DELTA);
        assertEquals(expRetirementDeduction, employee.getRetirementDeduction(), DELTA);
        assertEquals(expNetPay, employee.getNetPay(), DELTA);
    }

    @Test
    public void testWithoutRetirementPlanShift3() {
        System.out.println("testWithoutRetirementPlanShift3");
        Employee employee = new Employee(50, 3, false);
        employee.calculatePay();

        double hourlyPayRate = 90;
        double expRegularPay = 40 * hourlyPayRate;
        double expOvertimePay = (50 - 40) * hourlyPayRate * 1.5;
        double expTotalPay = expRegularPay + expOvertimePay;
        double expRetirementDeduction = 0;
        double expNetPay = expTotalPay - expRetirementDeduction;

        assertTrue(employee.isValidShift());
        assertEquals(expRegularPay, employee.getRegularPay(), DELTA);
        assertEquals(expOvertimePay, employee.getOvertimePay(), DELTA);
        assertEquals(expTotalPay, employee.getTotalPay(), DELTA);
        assertEquals(expRetirementDeduction, employee.getRetirementDeduction(), DELTA);
        assertEquals(expNetPay, employee.getNetPay(), DELTA);
    }

}
