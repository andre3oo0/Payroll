package andrew_payroll;

import java.io.*;

public class Employee {

    //attributes to store employee details
    private int hoursWorked;     
    private int shiftNumber;     
    private boolean hasRetirementPlan; 
    private double regularPay;       
    private double overtimePay;      
    private double totalPay;         
    private double retirementDeduction;
    private double netPay;            
    private boolean validShift;        

    //constructor to initialize employee attributes
    public Employee(int hoursWorked, int shiftNumber, boolean hasRetirementPlan) {
        this.hoursWorked = hoursWorked;
        this.shiftNumber = shiftNumber;
        this.hasRetirementPlan = hasRetirementPlan;
        //check if shift number is valid
        this.validShift = shiftNumber >= 1 && shiftNumber <= 3; 
    }

    //method to calculate the pay based on hours worked and shift number
    public void calculatePay() {
        //check for negative hours worked
        if (hoursWorked < 0) {
            throw new IllegalArgumentException("Hours worked cannot be negative.");
        }

        //if the shift number is invalid, set all pay attributes to zero
        if (!validShift) {
            regularPay = 0;
            overtimePay = 0;
            totalPay = 0;
            retirementDeduction = 0;
            netPay = 0;
            return;
        }

        //determine hourly pay rate based on the shift number
        double hourlyPayRate;
        switch (shiftNumber) {
            case 1:
                hourlyPayRate = 50; 
                break;
            case 2:
                hourlyPayRate = 70; 
                break;
            case 3:
                hourlyPayRate = 90; 
                break;
            default:
                hourlyPayRate = 0;
                break;
        }

        //calculate regular and overtime pay
        if (hoursWorked > 40) {
            //regular pay for 40 hours
            regularPay = 40 * hourlyPayRate;
            //overtime pay for hours over 40
            overtimePay = (hoursWorked - 40) * hourlyPayRate * 1.5; 
        } else {
            //regular pay for hours worked
            regularPay = hoursWorked * hourlyPayRate; 
            overtimePay = 0;
        }

        //calculate total pay
        totalPay = regularPay + overtimePay;

        //calculate retirement deduction if applicable
        if (shiftNumber != 1 && hasRetirementPlan) {
            //5% deduction for retirement plan
            retirementDeduction = 0.05 * totalPay; 
        } else {
            retirementDeduction = 0;
        }

        //calculate net pay after deductions
        netPay = totalPay - retirementDeduction;
    }

    //getter methods to access employee details
    public int getHoursWorked() {
        return hoursWorked;
    }

    public int getShiftNumber() {
        return shiftNumber;
    }

    public boolean hasRetirementPlan() {
        return hasRetirementPlan;
    }

    public double getRegularPay() {
        return regularPay;
    }

    public double getOvertimePay() {
        return overtimePay;
    }

    public double getTotalPay() {
        return totalPay;
    }

    public double getRetirementDeduction() {
        return retirementDeduction;
    }

    public double getNetPay() {
        return netPay;
    }

    public boolean isValidShift() {
        return validShift;
    }

    //method to append hours worked to a file
    public static void appendHoursToFile(int hoursWorked) throws IOException {
        //open file in append mode
        FileWriter fw = new FileWriter("hours_worked.txt", true); 
        //write hours worked to file
        fw.write(hoursWorked + "\n"); 
        //close the file
        fw.close(); 
    }

    //method to display the contents of a file
    public static void displayFileContents(String filename) throws IOException {
        //open file for reading
        BufferedReader br = new BufferedReader(new FileReader(filename)); 
        String line;
        //read each line from the file
        while ((line = br.readLine()) != null) { 
            //print the line
            System.out.println(line); 
        }
        //close the file
        br.close(); 
    }
}
