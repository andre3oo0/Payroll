package andrew_payroll;

import java.util.*;
import java.io.*;

public class Andrew_Payroll {

    public static void main(String[] args) {

        //create a scanner object to get input from the user
        Scanner sc = new Scanner(System.in);
        
        //create a list to store Employee objects
        ArrayList<Employee> employees = new ArrayList<>();

        //display a welcome message
        System.out.println("Welcome to UrbanFurn Payroll System");

        try {
            //open the file hours_worked.txt for reading and writing
            RandomAccessFile file = new RandomAccessFile("hours_worked.txt", "rw");

            int hoursWorked = -1;
            //loop until a valid number of hours worked is entered
            while (hoursWorked < 0) {
                System.out.println("Please enter how many hours you worked:");
                hoursWorked = sc.nextInt();
                if (hoursWorked < 0) {
                    
                    //display an error message if hours worked is negative
                    System.out.println("Hours worked cannot be negative. Please try again.");
                }
            }

            int shiftNumber = 0;
            
            //loop until a valid shift number is entered 
            while (shiftNumber < 1 || shiftNumber > 3) {
                System.out.println("Please enter your shift number:");
                shiftNumber = sc.nextInt();
                if (shiftNumber < 1 || shiftNumber > 3) {
                    
                    //display error message if shift number is not valid
                    System.out.println("Invalid shift number. Please enter 1, 2, or 3.");
                }
            }

            boolean retirementPlan = false;

            //ask the user if they want to participate in the retirement plan for shift 2 or 3
            if (shiftNumber == 2 || shiftNumber == 3) {
                System.out.println("Do you wish to participate in the retirement plan? (yes/no)");
                String choice = sc.next();
                if ("yes".equalsIgnoreCase(choice)) {
                    //set retirement plan to true if user answers yes
                    retirementPlan = true;
                }
            }

            //create a new Employee object with the input values
            Employee employee = new Employee(hoursWorked, shiftNumber, retirementPlan);
            
            //add the employee to the list of employees
            employees.add(employee);
            
            //calculate the pay for the employee
            employee.calculatePay();

            //display the details of the employee
            displayEmployeeDetails(employee);

            //move the file pointer to the end of the file and write the hours worked to the file
            file.seek(file.length());
            file.writeBytes(hoursWorked + "\n");

            //close the file
            file.close();
        } catch (IOException e) {
            //display error message if an exception occurs while handling the file
            System.out.println("An error occurred while handling the file.");
        }
    }

    //method to display the details of an employee
    private static void displayEmployeeDetails(Employee employee) {
        System.out.println("Employee Details:");
        System.out.println("Shift Number: " + employee.getShiftNumber());
        System.out.println("Hours Worked: " + employee.getHoursWorked());
        System.out.println("Regular Pay: " + "R" + employee.getRegularPay());
        System.out.println("Overtime Pay: " + "R" + employee.getOvertimePay());
        System.out.println("Total Pay: " + "R" + employee.getTotalPay());

        //display retirement deduction only for shift 2 or 3
        if (employee.getShiftNumber() == 2 || employee.getShiftNumber() == 3) {
            System.out.println("Retirement Deduction: " + "R" + employee.getRetirementDeduction());
        }

        System.out.println("Net Pay: " + "R" + employee.getNetPay());
    }
}
